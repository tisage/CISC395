# Demo Paper

Place a PDF file here for the demo.

Suggested sources (freely available):
- Any arxiv.org paper on LLMs (e.g., "Attention is All You Need")
- A short article from Google AI Blog
- Any course reading material

The demo prompt will be:
```
gemini "Summarize the key points of this paper in 5 bullet points" -f papers/your_paper.pdf
```
